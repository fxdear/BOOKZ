@echo off
setlocal
cd /d "%~dp0"
title BOOKZ EDU - Start Server
echo.
echo ================================================
echo       BOOKZ EDU - ЗАПУСК САЙТА
echo ================================================
echo.
where powershell.exe >nul 2>nul
if errorlevel 1 (
  echo ОШИБКА: в Windows не найден PowerShell.
  echo Запустите start-server.ps1 вручную в PowerShell.
  pause
  exit /b 1
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0start-server.ps1"
set "ERR=%ERRORLEVEL%"
if not "%ERR%"=="0" (
  echo.
  echo Сервер не запустился. Код ошибки: %ERR%
  echo Проверьте, что папка public находится рядом с этим файлом.
  pause
)
endlocal

﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$web = [IO.Path]::GetFullPath((Join-Path $root 'public'))
if (-not (Test-Path (Join-Path $web 'index.html'))) { Write-Host 'Не найдена public\index.html. Распакуйте ZIP полностью.' -ForegroundColor Red; exit 1 }
$listener = $null
$port = 8000
for ($p = 8000; $p -lt 8030; $p++) {
  try { $candidate = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, $p); $candidate.Start(); $listener = $candidate; $port = $p; break } catch { if ($candidate) { $candidate.Stop() } }
}
if ($null -eq $listener) { Write-Host 'Не удалось запустить сервер: порты 8000–8029 заняты или заблокированы.' -ForegroundColor Red; exit 2 }
$url = "http://127.0.0.1:$port/"
Write-Host ''
Write-Host '======================================================' -ForegroundColor Cyan
Write-Host ' BOOKZ EDU — СЕРВЕР УСПЕШНО ЗАПУЩЕН' -ForegroundColor Green
Write-Host " Сайт: $url" -ForegroundColor White
Write-Host ' Окно не закрывайте. Для остановки нажмите Ctrl+C.' -ForegroundColor Yellow
Write-Host '======================================================' -ForegroundColor Cyan
Start-Process $url
$mime = @{ '.html'='text/html; charset=utf-8'; '.js'='application/javascript; charset=utf-8'; '.css'='text/css; charset=utf-8'; '.json'='application/json; charset=utf-8'; '.svg'='image/svg+xml'; '.png'='image/png'; '.jpg'='image/jpeg'; '.jpeg'='image/jpeg'; '.webp'='image/webp'; '.ico'='image/x-icon' }
try {
 while ($true) {
  $client = $listener.AcceptTcpClient()
  try {
   $stream = $client.GetStream()
   $reader = New-Object IO.StreamReader($stream, [Text.Encoding]::ASCII, $false, 1024, $true)
   $requestLine = $reader.ReadLine()
   if ([string]::IsNullOrWhiteSpace($requestLine)) { continue }
   $parts = $requestLine.Split(' ')
   $method = $parts[0]
   $rawPath = if ($parts.Length -gt 1) { $parts[1].Split('?')[0] } else { '/' }
   while ($true) { $headerLine = $reader.ReadLine(); if ([string]::IsNullOrEmpty($headerLine)) { break } }
   $status = '200 OK'; $contentType = 'text/plain; charset=utf-8'; $bytes = [byte[]]@()
   if ($method -ne 'GET' -and $method -ne 'HEAD') { $status='405 Method Not Allowed'; $bytes=[Text.Encoding]::UTF8.GetBytes('Method not allowed') }
   elseif ($rawPath -eq '/api/health') { $contentType='application/json; charset=utf-8'; $bytes=[Text.Encoding]::UTF8.GetBytes('{"ok":true,"service":"BOOKZ EDU"}') }
   elseif ($rawPath -eq '/api/catalog') { $file=Join-Path $web 'data/catalog.json'; $contentType='application/json; charset=utf-8'; $bytes=[IO.File]::ReadAllBytes($file) }
   else {
    $relative = [Uri]::UnescapeDataString($rawPath.TrimStart('/')).Replace('/', [IO.Path]::DirectorySeparatorChar)
    if ([string]::IsNullOrWhiteSpace($relative)) { $relative='index.html' }
    $file = [IO.Path]::GetFullPath((Join-Path $web $relative))
    $prefix = $web.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    if (-not $file.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $file -PathType Leaf)) { $status='404 Not Found'; $bytes=[Text.Encoding]::UTF8.GetBytes('404 Not Found') }
    else { $bytes=[IO.File]::ReadAllBytes($file); $ext=[IO.Path]::GetExtension($file).ToLowerInvariant(); if ($mime.ContainsKey($ext)) { $contentType=$mime[$ext] } else { $contentType='application/octet-stream' } }
   }
   $head = "HTTP/1.1 $status`r`nContent-Type: $contentType`r`nContent-Length: $($bytes.Length)`r`nCache-Control: no-store`r`nConnection: close`r`n`r`n"
   $headBytes=[Text.Encoding]::ASCII.GetBytes($head); $stream.Write($headBytes,0,$headBytes.Length)
   if ($method -ne 'HEAD' -and $bytes.Length -gt 0) { $stream.Write($bytes,0,$bytes.Length) }
   $stream.Flush()
  } catch { }
  finally { if ($client) { $client.Close() } }
 }
} finally { $listener.Stop() }

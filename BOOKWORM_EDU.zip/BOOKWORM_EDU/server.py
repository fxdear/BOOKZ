#!/usr/bin/env python3
"""BOOKZ EDU local web server (Python 3 standard library only)."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlsplit, unquote
import json, os, threading, webbrowser
BASE=Path(__file__).resolve().parent
PUBLIC=BASE/'public'
HOST='127.0.0.1'
START_PORT=int(os.environ.get('BOOKZ_PORT','8000'))
if not (PUBLIC/'index.html').is_file():
    raise SystemExit('BOOKZ: не найдена public/index.html. Распакуйте архив полностью.')
class Handler(SimpleHTTPRequestHandler):
    def translate_path(self,path):
        clean=unquote(urlsplit(path).path).lstrip('/')
        target=(PUBLIC/clean) if clean else (PUBLIC/'index.html')
        try:
            resolved=target.resolve(); root=PUBLIC.resolve()
            if resolved!=root and root not in resolved.parents: return str(PUBLIC/'__not_found__')
        except Exception: return str(PUBLIC/'__not_found__')
        return str(target)
    def do_GET(self):
        path=urlsplit(self.path).path
        if path=='/api/health': return self.send_json({'ok':True,'service':'BOOKZ EDU','url':'/'})
        if path=='/api/catalog':
            f=PUBLIC/'data/catalog.json'
            if not f.is_file(): return self.send_error(404,'Catalog not found')
            body=f.read_bytes(); self.send_response(200); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(body))); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(body); return
        return super().do_GET()
    def send_json(self,data):
        body=json.dumps(data,ensure_ascii=False).encode(); self.send_response(200); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(body))); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(body)
    def end_headers(self):
        if self.path=='/' or self.path.endswith(('.html','.js','.css')): self.send_header('Cache-Control','no-store')
        super().end_headers()
class Server(ThreadingHTTPServer): allow_reuse_address=True; daemon_threads=True
server=None; last_error=None
for port in range(START_PORT,START_PORT+30):
    try: server=Server((HOST,port),Handler); break
    except OSError as exc: last_error=exc
if server is None: raise SystemExit(f'BOOKZ: не удалось открыть порты {START_PORT}–{START_PORT+29}: {last_error}')
port=server.server_address[1]; url=f'http://{HOST}:{port}/'
print('\n'+'='*54,flush=True); print('BOOKZ EDU: СЕРВЕР УСПЕШНО ЗАПУЩЕН',flush=True); print('Сайт: '+url,flush=True); print('Проверка: '+url+'api/health',flush=True); print('Для остановки нажмите Ctrl+C. Не закрывайте это окно.',flush=True); print('='*54+'\n',flush=True)
threading.Timer(1.0,lambda:webbrowser.open(url)).start()
try: server.serve_forever()
except KeyboardInterrupt: print('\nСервер остановлен.',flush=True)
finally: server.server_close()

const prisma=require('../db');
const {hashToken}=require('../security');
async function auth(req,res,next){
  try{
    const token=req.cookies?.bp_session;
    if(!token){req.user=null;return next();}
    const user=await prisma.user.findUnique({where:{id:token.split('.')[0]},include:{roles:{include:{role:{include:{permissions:{include:{permission:true}}}}}}}});
    if(!user || user.status!=='ACTIVE'){req.user=null;return next();}
    const expected=hashToken(`${user.id}:${process.env.SESSION_SECRET}`);
    if(token.split('.')[1]!==expected){req.user=null;return next();}
    req.user=user; req.permissions=new Set(user.roles.flatMap(r=>r.role.permissions.map(p=>p.permission.key)));
    next();
  }catch(e){next(e);}
}
function requireAuth(req,res,next){if(!req.user)return res.status(401).json({error:'Требуется авторизация'});next();}
function requirePermission(key){return (req,res,next)=>{if(!req.user)return res.status(401).json({error:'Требуется авторизация'});if(!req.permissions?.has(key))return res.status(403).json({error:'Недостаточно прав'});next();};}
module.exports={auth,requireAuth,requirePermission};

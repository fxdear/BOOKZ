const crypto = require('node:crypto');
function hashToken(value){ return crypto.createHash('sha256').update(value).digest('hex'); }
function safeEqual(a,b){ const x=Buffer.from(String(a)); const y=Buffer.from(String(b)); return x.length===y.length && crypto.timingSafeEqual(x,y); }
module.exports={hashToken,safeEqual};

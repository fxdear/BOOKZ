async function cdekRequest(path,body){
 const {CDEK_CLIENT_ID:id,CDEK_CLIENT_SECRET:secret,CDEK_API_URL='https://api.cdek.ru/v2'}=process.env;
 if(!id||!secret)throw Object.assign(new Error('СДЭК не настроен: требуется Client ID и Client Secret'),{status:503});
 const tokenRes=await fetch(`${CDEK_API_URL}/oauth/token`,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'client_credentials',client_id:id,client_secret:secret})});
 const token=await tokenRes.json();if(!tokenRes.ok)throw Object.assign(new Error('Не удалось авторизоваться в СДЭК'),{status:502});
 const r=await fetch(`${CDEK_API_URL}${path}`,{method:'POST',headers:{Authorization:`Bearer ${token.access_token}`,'Content-Type':'application/json'},body:JSON.stringify(body)});
 const data=await r.json();if(!r.ok)throw Object.assign(new Error('Ошибка API СДЭК'),{status:502});return data;
}
module.exports={cdekRequest};

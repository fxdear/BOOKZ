const prisma=require('../db');
const crypto=require('node:crypto');
async function createYooKassaPayment(order){
  const {YOOKASSA_SHOP_ID,YOOKASSA_SECRET_KEY,YOOKASSA_RETURN_URL}=process.env;
  if(!YOOKASSA_SHOP_ID||!YOOKASSA_SECRET_KEY) throw Object.assign(new Error('ЮKassa не настроена: добавьте ключи в .env'),{status:503});
  const idempotenceKey=crypto.randomUUID();
  const auth=Buffer.from(`${YOOKASSA_SHOP_ID}:${YOOKASSA_SECRET_KEY}`).toString('base64');
  const response=await fetch('https://api.yookassa.ru/v3/payments',{method:'POST',headers:{Authorization:`Basic ${auth}`,'Content-Type':'application/json','Idempotence-Key':idempotenceKey},body:JSON.stringify({amount:{value:Number(order.total).toFixed(2),currency:'RUB'},capture:true,confirmation:{type:'redirect',return_url:YOOKASSA_RETURN_URL},description:`Заказ ${order.number}`,metadata:{orderId:order.id}})});
  const data=await response.json();
  if(!response.ok) throw Object.assign(new Error(data.description||'Ошибка создания платежа'),{status:502});
  await prisma.payment.upsert({where:{orderId:order.id},create:{orderId:order.id,provider:'YOOKASSA',providerPaymentId:data.id,status:'PENDING',amount:order.total,confirmationUrl:data.confirmation?.confirmation_url},update:{providerPaymentId:data.id,status:'PENDING',confirmationUrl:data.confirmation?.confirmation_url}});
  return data;
}
async function processYooKassaWebhook(event){
  const obj=event.object;if(!obj?.id)return;
  const payment=await prisma.payment.findFirst({where:{providerPaymentId:obj.id},include:{order:true}});
  if(!payment)return;
  if(payment.status==='SUCCEEDED' || payment.status==='REFUNDED')return;
  // Never trust the webhook body alone: fetch the payment from YooKassa's authenticated API.
  const auth=Buffer.from(`${process.env.YOOKASSA_SHOP_ID}:${process.env.YOOKASSA_SECRET_KEY}`).toString('base64');
  const verifiedResponse=await fetch(`https://api.yookassa.ru/v3/payments/${encodeURIComponent(obj.id)}`,{headers:{Authorization:`Basic ${auth}`}});
  if(!verifiedResponse.ok)throw Object.assign(new Error('Не удалось подтвердить платёж через ЮKassa'),{status:502});
  const verified=await verifiedResponse.json();
  if(verified.id!==payment.providerPaymentId || verified.metadata?.orderId!==payment.orderId || Number(verified.amount?.value)!==Number(payment.amount)) throw Object.assign(new Error('Данные webhook не совпадают с подтверждённым платежом'),{status:400});
  if(event.event==='payment.succeeded' && verified.status==='succeeded'){
    await prisma.$transaction(async tx=>{
      await tx.payment.update({where:{id:payment.id},data:{status:'SUCCEEDED',rawEvent:event}});
      await tx.order.update({where:{id:payment.orderId},data:{status:'PAID'}});
      const lines=await tx.orderItem.findMany({where:{orderId:payment.orderId}});
      for(const line of lines){if(!line.bookId)continue;await tx.book.update({where:{id:line.bookId},data:{stock:{decrement:line.quantity},reserved:{decrement:line.quantity}}});await tx.inventoryMovement.create({data:{bookId:line.bookId,type:'SALE',quantity:-line.quantity,note:`Оплачен заказ ${payment.order.number}`}});}
    });
  } else if(event.event==='payment.canceled' && verified.status==='canceled'){
    await prisma.$transaction(async tx=>{
      await tx.payment.update({where:{id:payment.id},data:{status:'CANCELED',rawEvent:event}});
      await tx.order.update({where:{id:payment.orderId},data:{status:'CANCELLED'}});
      const lines=await tx.orderItem.findMany({where:{orderId:payment.orderId}});
      for(const line of lines){if(!line.bookId)continue;await tx.book.update({where:{id:line.bookId},data:{reserved:{decrement:line.quantity}}});await tx.inventoryMovement.create({data:{bookId:line.bookId,type:'RELEASE',quantity:line.quantity,note:`Освобождён резерв заказа ${payment.order.number}`}});}
    });
  }
}
module.exports={createYooKassaPayment,processYooKassaWebhook};

const router=require('express').Router();const prisma=require('../db');
router.get('/categories',async(req,res,next)=>{try{res.json(await prisma.category.findMany({orderBy:{sortOrder:'asc'}}));}catch(e){next(e);}});
router.get('/books',async(req,res,next)=>{try{
 const {q,category,author,publisher,subject,grade,minPrice,maxPrice,sort='new',page='1',limit='24'}=req.query;
 const where={active:true,...(q?{OR:[{title:{contains:q,mode:'insensitive'}},{isbn:{contains:q}},{sku:{contains:q}},{authors:{some:{author:{name:{contains:q,mode:'insensitive'}}}}}]}:{}),
 ...(category?{categories:{some:{category:{slug:category}}}}:{}),...(author?{authors:{some:{author:{name:{contains:author,mode:'insensitive'}}}}}:{}),
 ...(publisher?{publisher:{name:{contains:publisher,mode:'insensitive'}}}:{}),...(subject?{subject:{name:subject}}:{}),...(grade?{grade:{number:Number(grade)}}:{}),
 ...(minPrice||maxPrice?{price:{...(minPrice?{gte:Number(minPrice)}:{}),...(maxPrice?{lte:Number(maxPrice)}:{})}}:{})};
 const orderBy=sort==='price_asc'?{price:'asc'}:sort==='price_desc'?{price:'desc'}:sort==='popular'?{orderItems:{_count:'desc'}}:{createdAt:'desc'};
 const take=Math.min(60,Math.max(1,Number(limit)||24)),skip=(Math.max(1,Number(page)||1)-1)*take;
 const [items,total]=await prisma.$transaction([prisma.book.findMany({where,include:{authors:{include:{author:true}},publisher:true,categories:{include:{category:true}},subject:true,grade:true},orderBy,skip,take}),prisma.book.count({where})]);
 res.json({items,total,page:Number(page)||1,pages:Math.ceil(total/take)});
 }catch(e){next(e);}});
router.get('/books/:slug',async(req,res,next)=>{try{const b=await prisma.book.findUnique({where:{slug:req.params.slug},include:{authors:{include:{author:true}},publisher:true,categories:{include:{category:true}},subject:true,grade:true,chapters:{where:{permitted:true},orderBy:{sortOrder:'asc'}},reviews:{where:{status:'APPROVED'},include:{user:{select:{firstName:true}}}}}});if(!b||!b.active)return res.status(404).json({error:'Книга не найдена'});res.json(b);}catch(e){next(e);}});
module.exports=router;
